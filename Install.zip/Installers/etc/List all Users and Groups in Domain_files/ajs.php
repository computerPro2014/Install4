<!DOCTYPE html>
<html dir="ltr" lang="en-US">
<head>
<meta charset="UTF-8" />
<title>
Blue Whale Web |   Page not found</title>
<link rel="profile" href="http://gmpg.org/xfn/11" />
<link rel="pingback" href="http://www.bluewhaleweb.com/xmlrpc.php" />
<link rel="stylesheet" type="text/css" media="all" href="http://www.bluewhaleweb.com/wp-content/themes/toommorel-lite/style.css" />
<meta name='robots' content='noindex,nofollow' />
<link rel="alternate" type="application/rss+xml" title="Blue Whale Web &raquo; Feed" href="http://www.bluewhaleweb.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="Blue Whale Web &raquo; Comments Feed" href="http://www.bluewhaleweb.com/comments/feed/" />
<link rel='stylesheet' id='coloroptions-css'  href='http://www.bluewhaleweb.com/wp-content/themes/toommorel-lite/css/blue.css?ver=3.3.1' type='text/css' media='all' />
<link rel='stylesheet' id='contact-form-7-css'  href='http://www.bluewhaleweb.com/wp-content/plugins/contact-form-7/styles.css?ver=3.1.1' type='text/css' media='all' />
<script type='text/javascript' src='https://ajax.googleapis.com/ajax/libs/jquery/1.6.2/jquery.min.js?ver=1.6.1'></script>
<script type='text/javascript' src='http://www.bluewhaleweb.com/wp-content/themes/toommorel-lite/js/ddsmoothmenu.js?ver=3.3.1'></script>
<script type='text/javascript' src='http://www.bluewhaleweb.com/wp-content/themes/toommorel-lite/js/ddsmoothmenu-init.js?ver=3.3.1'></script>
<script type='text/javascript' src='http://www.bluewhaleweb.com/wp-content/themes/toommorel-lite/js/image-effect.js?ver=3.3.1'></script>
<script type='text/javascript' src='http://www.bluewhaleweb.com/wp-content/themes/toommorel-lite/js/jquery.scrollTo-min.js?ver=3.3.1'></script>
<script type='text/javascript' src='http://www.bluewhaleweb.com/wp-content/themes/toommorel-lite/js/stylesheetToggle.js?ver=3.3.1'></script>
<script type='text/javascript' src='http://www.bluewhaleweb.com/wp-content/themes/toommorel-lite/js/cufon-yui.js?ver=3.3.1'></script>
<script type='text/javascript' src='http://www.bluewhaleweb.com/wp-content/themes/toommorel-lite/js/DIN_400-DIN_700.font.js?ver=3.3.1'></script>
<script type='text/javascript' src='http://www.bluewhaleweb.com/wp-content/themes/toommorel-lite/js/jquery.tipsy.js?ver=3.3.1'></script>
<script type='text/javascript' src='http://www.bluewhaleweb.com/wp-content/themes/toommorel-lite/js/zoombox.js?ver=3.3.1'></script>
<script type='text/javascript' src='http://www.bluewhaleweb.com/wp-content/themes/toommorel-lite/js/jquery.validate.min.js?ver=3.3.1'></script>
<script type='text/javascript' src='http://www.bluewhaleweb.com/wp-content/themes/toommorel-lite/js/verif.js?ver=3.3.1'></script>
<script type='text/javascript' src='http://www.bluewhaleweb.com/wp-content/themes/toommorel-lite/js/custom.js?ver=3.3.1'></script>
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://www.bluewhaleweb.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://www.bluewhaleweb.com/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 3.3.1" />
<link rel="shortcut icon" href="http://www.bluewhaleweb.com/wp-content/themes/toommorel-lite/images/favicon.ico" />
</head>
<body  class="error404" style="background:url(background:url('images/bodybg.png'););" >
<!--Start Container-->
<div class="container_24">
  <!--Start Main-->
  <div class="grid_24 header_wrapper">
    <!--Start Header Div-->
    <div class="header">
      <div class="logo"><a href="http://www.bluewhaleweb.com"><img src="http://www.bluewhaleweb.com/wp-content/uploads/2012/02/logocolortrans3.gif" alt="Blue Whale Web" /></a> </div>
    </div>
    <!--End Header Div-->
    <div class="clear"></div>
  </div>
</div>
<div class="clear"></div>
<!--Start Container-->
<div class="container_24">
<!--Start Main-->
<div class="grid_24">
<!--Start Menubar-->
<!--Start Main_wrapper-->
<div class="menu_wrapper">
<div class="menu_bar">
  <div id="MainNav">
    <!--Start menu-div-->
    <div id="menu" class="menu-top-navigation-container"><ul id="menu-top-navigation" class="ddsmoothmenu"><li id="menu-item-21" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-21"><a href="http://www.bluewhaleweb.com/">Home</a></li>
<li id="menu-item-22" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-22"><a href="#contact-form">Contact Us</a></li>
</ul></div>    <!--End menu-div-->
  </div>
</div>
<!--End Menubar-->
<!--Start right nav-->
<div class="right_navi_top">
  <div id="topSocial">
                                          </div>
</div>
<!--End right nav-->
<div class="clear"></div>
</div>
</div>
</div>
<div class="clear"></div>
<div class="wrap">
  <div class="bg_line">
      <div class="container_24">
          <div class="grid_24">
              <div class="header_line"></div>
          </div>
          <div class="clear"></div>
      </div>
  </div>
</div>
<div class="clear"></div>
<div class="container_24">
<!--Start Main-->
<div class="grid_24 main">
<!--Start Menubar-->
<!--Start Main_wrapper-->
<div class="main_wrapper"><div class="clear"></div>
<div class="content page">
  <h2>404: The Page you are looking for is not found.</h2>
  <h4>You have landed on the Wrong Page..</h4>
  <h4><a href="http://www.bluewhaleweb.com">Click Here to Visit our Home Page</a></h4>
  <h6> Make a Search if you want to find something specific</h6>
  <div class="search">
    <form role="search" method="get" id="searchform" action="#" >
      <div>
        <input type="text" onFocus="this.value='';"  onblur="this.value=!this.value?'Search':this.value;" value="" name="s" id="s" />
        <input type="submit" id="searchsubmit" value="Search" />
      </div>
    </form>
  </div>
</div>
<!--End Content-->
<div class="clear"></div>
<div class="hr_big"></div>
<!--End Content Wrapper-->
</div>
<div class="clear"></div>
<!--End Main_wrapper-->
<!--
<!--Start Footer-->
<div class="footer">
  <ul class="footer_left_menu">
    <li><a href="http://www.bluewhaleweb.com">Blue Whale Web - </a></li>
  </ul>
<!--  
<ul class="footer_right_menu">
    <li><a href="http://www.inkthemes.com">Designed &amp; Developed by InkThemes.com</a></li>
</ul>
-->
</div>
<div class="clear"></div>
<!--End Footer-->
</div>
<!--End Main-->
<div class="clear"></div>
</div>
<!--End Container-->
<script type='text/javascript' src='http://www.bluewhaleweb.com/wp-content/plugins/contact-form-7/jquery.form.js?ver=2.96'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var _wpcf7 = {"loaderUrl":"http:\/\/www.bluewhaleweb.com\/wp-content\/plugins\/contact-form-7\/images\/ajax-loader.gif","sending":"Sending ..."};
/* ]]> */
</script>
<script type='text/javascript' src='http://www.bluewhaleweb.com/wp-content/plugins/contact-form-7/scripts.js?ver=3.1.1'></script>
</body></html>
